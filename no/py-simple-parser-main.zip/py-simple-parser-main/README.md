# py-simple-parser
Simple python parser. Parse a simple mathematical expression with vanilla python.

Examples:
* 2+3*(4 + 5.5)
* 6/2^2
* 12*(15+(2*3))

Currently supports:
* Addition (+)
* Substraction (-)
* Multiplication(*)
* Division(/)
* Power/Exponent (^)
* Parenthesization ( )


## Usage
1. Clone this repo.
2. Run the script **main.py**.
3. Type in a mathematical expression.


## Developer
  * Oscar Juárez
